package com.d208.AIclerk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AIclerkApplicationTests {

	@Test
	void contextLoads() {
	}

}
