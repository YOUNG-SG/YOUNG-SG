package com.d208.AIclerk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AIclerkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AIclerkApplication.class, args);
	}

}
