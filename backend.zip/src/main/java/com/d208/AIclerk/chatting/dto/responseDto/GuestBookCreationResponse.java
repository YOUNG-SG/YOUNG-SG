package com.d208.AIclerk.chatting.dto.responseDto;

import lombok.Data;

@Data
public class GuestBookCreationResponse {
    private long id;
    private String status;
}
