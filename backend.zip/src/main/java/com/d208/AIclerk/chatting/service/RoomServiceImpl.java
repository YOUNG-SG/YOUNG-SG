package com.d208.AIclerk.chatting.service;

import com.d208.AIclerk.chatting.util.InviteCodeGenerator;
import com.d208.AIclerk.entity.MeetingRoom;
import com.d208.AIclerk.chatting.repository.MeetingRoomRepository;
import com.d208.AIclerk.config.RabbitMQConfig;
import com.d208.AIclerk.config.ReddisConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalTime;



@Service
public class RoomServiceImpl implements RoomService {
    @Autowired
    private MeetingRoomRepository meetingRoomRepository;
    @Autowired
    private RabbitMQConfig rabbitMQConfig;
    @Autowired
    private ReddisConfig redisService;
    @Autowired
    private InviteCodeGenerator inviteCodeGenerator;


    //
    @Override
    public MeetingRoom createRoom(MeetingRoom room, String ownerId) { //미팅룸에
        String inviteCode = inviteCodeGenerator.generateInviteCode();
        room.setStartTime(LocalTime.now());
        room.setInviteCode(inviteCode);
        // Save room in MySQL
        MeetingRoom savedRoom = meetingRoomRepository.save(room);

        // redis 참여자,방장 상태임시로 저장
        redisService.createRoom(savedRoom.getId().toString(), ownerId, "0");
        // 해당 룸에대하여 routing_key를 설정
        rabbitMQConfig.configureQueueForRoom(savedRoom.getId().toString());
        return savedRoom;
    }


    //방접속 reddis 에 참여자정보추가 // RabbitMQ에 해당유저가 Routing_key 유저
    public void joinRoom(String roomId, String memberId) {
        redisService.joinRoom(roomId, memberId);
    }
}




